<?php if (!defined('FW')) die('Forbidden');

$manifest = array(
	'version'       => '1.3.13',
	'display'       => false,
	'standalone'    => true,
	'requirements'  => array(
		'extensions'  => array(
			'builder' => array(),
		),
	),
	'github_update' => 'ThemeFuse/Unyson-Shortcodes-Extension'
);
