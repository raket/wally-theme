<?php if (!defined('FW')) {
	die('Forbidden');
}

$options = array(
	'is_fullwidth' => array(
		'label'        => __('Full Width', 'fw'),
		'type'         => 'switch',
	),
	'border' => array(
		'label'        => __('Borders', 'fw'),
		'type'         => 'switch',
	),

);