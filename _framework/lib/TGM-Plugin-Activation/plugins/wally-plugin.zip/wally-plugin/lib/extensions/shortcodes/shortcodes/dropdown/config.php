<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
		'title'       => __( 'Select button', 'fw' ),
		'description' => __( 'Add a button with multiple alternatives', 'fw' ),
		'tab'         => __( 'Content Elements', 'fw' ),
		'icon'        => 'unycon unycon-list-ul',
);