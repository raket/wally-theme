<?php
// Block direct requests
if ( !defined('ABSPATH') )
	die('-1');

class Wally_Bootstrap {
	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		add_option('wally_do_activation_redirect', true);
	}

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {
	}

}